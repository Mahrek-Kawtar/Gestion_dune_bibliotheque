#ifndef DEF_CD
#define DEF_CD

#include "Ressources.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <vector>

class CD :public Ressources {
 public:

 CD();
 CD(std::string _titre,int _duree,int _nbr_piste,std::string _auteur,std::string _maison_prod); //a verifier
 ~CD();

  //others

    virtual void ajouter();
    virtual void afficher();

    //La saisi des caractéristiques

    int ret_duree();
    std::string ret_auteur();
    int ret_nbr_piste ();
    std::string ret_maison_prod ();

    void save_cd (std:: string  filename);

    //affectation des caractéristiques (pour modifier les valeurs...)
/*
    void affect_duree(int _duree);
    void affect_auteur(std::string _auteur );
    void affect_nbr_piste (int _nbr_piste);
    void affect_maison_prod(std::string _maison_prod );
*/
void set_duree(int nv_duree);
void set_etat(std ::string nv_etat);

void set_auteur(std::string nv_auteur);
void set_type(std::string nv_type);
void set_nbr_piste (int nv_nbr_piste);
void set_maison_prod (std::string nv_maison_prod);
void set_titre(std::string nv_titre);
void set_id(int nv_id);

 private:

 int duree;
 int nbr_piste;
 std::string auteur;
 std::string maison_prod;

};
#endif
