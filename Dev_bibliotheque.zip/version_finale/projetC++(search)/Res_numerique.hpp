#ifndef DEF_RES_NUMERIQUE
#define DEF_RES_NUMERIQUE

#include "Ressources.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <vector>

class Res_numerique :public Ressources
{
    public:
    Res_numerique() ;
    Res_numerique( int _taille ,std::string _auteur,std::string _type,std::string _nom,std::string _chemin_acces);//
    ~Res_numerique() ;



    //others

    virtual void ajouter();
    virtual void afficher();

    //La saisi des caractéristiques

    int ret_taille();
    std::string ret_auteur();
    std::string ret_type();
    std::string ret_nom();
    std::string ret_chemin();

    void set_taille(int nv_taille);
    void set_type(std::string nv_type);
      void set_auteur(std::string nv_auteur);
      void set_type_num(std::string nv_type_num);
      void set_nom(std::string nv_nom);
      void set_etat(std::string nv_etat);
      void set_chemin(std::string nv_chemin_acces);
      void set_titre(std::string nv_titre);
      void set_id(int nv_id);


    void affectation(int _taille,std::string _auteur,std::string _type,std::string _nom, std::string _chemin_acces);
    void save_re_num(std:: string filename);





    private:
    std::string auteur;
    std::string type_num;
    int taille ;
    std::string nom;
    std::string chemin_acces;
};
#endif
