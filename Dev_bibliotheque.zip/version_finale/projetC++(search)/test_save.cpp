#include <iostream>
#include "Mediatheque.hpp"
#include "Ressources.hpp"


using namespace std;

int main()
{

    Mediatheque *m = new Mediatheque();
    string filename="fichier.txt";
    m->Save(filename);
    return 1;
  }
