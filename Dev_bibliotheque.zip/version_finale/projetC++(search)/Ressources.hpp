#ifndef DEF_RESSOURCES
#define DEF_RESSOURCES

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <cstdlib>

class Ressources
{


//METHODES

    public:

    //constructeurs et destructeur
    Ressources();
    Ressources( std::string _type ,int _id, std::string _etat, std::string  _titre);
    ~Ressources();

    virtual void afficher();
    void ajouter();


    //La saisi des caractéristiques

    std::string retourner_type();
    int retourner_id();
    std::string retourner_etat ();
    std::string retourner_titre ();


    //affectation des caractéristiques (on pourait les mettres tous dans une seule fonction!)

    void affectation_etat(std::string _etat);

    void affectation (std::string _type,int _id, std::string _etat,std::string _titre);



//ATTRIBUTS
  protected:

    std::string type ;
    int id;
    std::string etat;
    std::string  titre;
};
#endif
