#ifndef DEF_MEDIATHEQUE
#define DEF_MEDIATHEQUE

#include <iostream>
#include <string>
#include <vector>
#include "Ressources.hpp"

using namespace std;

class Mediatheque
{

//METHODES

    public:

    //constructeurs et destructeur

    Mediatheque();
  //  Mediatheque(vector<Ressources*> liste_des_ressources, vector<Ressources*> liste_pour_recherche);
    ~Mediatheque();



    void Bye();          //detruire la mediatheque
    void Add( std::string _type);//on donne le type qu on veut ajouter en respectant la notation, ainsi que l identifiant , le titre et l'etat
    void Load( std::string filename) ;
    void Save( std::string filename) ;
    void Search (std::string mot ); //elle va generer un fichier
    void Clear(); //remet le fichier générer par Search à son etat initial
    void Show_id(int _identifiant);
    void List (); //permet de lire le fichier générer par Search
    void Delete(int id);
    void Reset();  //detruire les ressources (vector)
    void Use (int id, std::string action);
//mode d utilisation(emprunt,retour, reserv)


//ATTRIBUTS

  //  private:

   vector<Ressources*> liste_des_ressources;
   vector<Ressources*> liste_pour_recherche;
   vector<Ressources*> resultats_recherche;
   // #####


};
#endif
