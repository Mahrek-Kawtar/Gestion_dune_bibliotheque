#ifndef DEF_DVD
#define DEF_DVD
#include "Ressources.hpp"

#include "VHS.hpp"
#include <iostream>
#include <string>
#include <vector>

class DVD : public VHS {
    public:

  DVD();
  DVD(int _duree,std::string _auteur, std::string _maison_prod,int _nbr_piste);
  ~DVD() ;



    //others

    virtual void ajouter();

    virtual void afficher();

    //La saisi des caractéristiques

        void set_duree(int nv_duree);
        void set_auteur(std::string nv_auteur);
        void set_type(std::string nv_type);
        void set_nbr_piste (int nv_nbr_piste);
        void set_maison_prod (std::string nv_maison_prod);
        void set_titre(std::string nv_titre);
        void set_id(int nv_id);
        void set_etat(std::string nv_etat);
        
    int ret_nbr_piste();
    void affectation(int _nbr_piste);

    void save_dvd(std::string filename);


//ATTRIBUTS
  private:

    int nbr_piste;
    int duree;
    std::string auteur;
    std::string maison_prod;


};
#endif
