#include <iostream>
#include "Mediatheque.hpp"
#include <vector>


using namespace std;

int main()
  {
    Mediatheque *m = new Mediatheque();


    cout<<"~~~~~~~~~~~~~~~Bienvenue dans notre mediatheque numerique~~~~~~~~~~~~ "<<endl;
    cout<<endl;
    cout<<"Nous avons deux mode d'utilisation:"<<endl;
    cout<<"A-Administrateur"<<endl;
    cout<<"B-Client"<<endl;
    cout<<endl;
    cout<<"Merci de choisir A ou B"<<endl;
    string utilisateur;
    string mot_de_passe;
    int acces1 =0 ;//acces de Administrateur
    int acces2=0 ; // acces pour client
    getline(cin, utilisateur);

    if(utilisateur == "A")
    {
        cout<<"inserer votre mot de passe :"<<endl;
        getline(cin,mot_de_passe);

        if(mot_de_passe == "Asmae" || mot_de_passe=="Kawtar")
        {
              acces1 =1;
        }
        else
        {
          cout<<"votre mot de passe est incorrecte "<<endl;
        }
    }

    if(utilisateur == "B")
    {
        cout<<"inserer votre mot de passe :"<<endl;
        getline(cin,mot_de_passe);

        if(mot_de_passe == "Asmae" || mot_de_passe=="Kawtar")
        {
              acces2 =1;
        }
        else
        {
          cout<<"votre mot de passe est incorrecte "<<endl;
        }
    }


    m->Clear();

    while(1)
    {
      if(acces1 ==1)
      {
        cout<<endl;
        cout<<endl;
        cout<<"vous etes connecte dans la mediatheque en tant qu'administrateur "<<endl;
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        cout<<endl;
        cout<<"En tant qu'administrarteur , vous avez l'acces aux fonctions suivantes:"<<endl;
        cout<<endl;
        cout<<"1-Add: Ajouter une ressource "<<endl;
        cout<<"2-Load: Charger les ressources depuis un fichier"<<endl;
        cout<<"3-Save:Sauvegarder les ressources dans un fichier"<<endl;
        cout<<"4-List:Lister toutes les ressources disponibles"<<endl;
        cout<<"5-Delete:Supprimer une ressource"<<endl;
        cout<<"6-Show:Afficher les details d'une ressource donnee"<<endl;
        cout<<"7-Search:Rechercher une ressource"<<endl;
        cout<<"8-Clear:Reinitialiser la recherche"<<endl;
        cout<<"9-Reset:Reinitialiser la mediatheque"<<endl;
        cout<<"10-Bye:quiter l'espace"<<endl;
        cout<<"11-changer le mode de connexion"<<endl;
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;

        cout << endl;
        cout << endl;

        bool menu=false;
        while(!menu)
        {
            int fonction;
            cout<<"Taper le numero de l'action que vous souhaitez effectuer "<<endl;
            cin>>fonction;
            cin.ignore();//pour vider le tompon pour l'entree suivante


            if(fonction ==1)
            {
              string type;
              cout<<"le type de la ressource a ajouter: "<<endl;
              getline(cin,type);
              m->Add(type);
              break;
            }
            else if(fonction == 2 )
            {
              string filename;
              cout<< "Indiquez le nom du fichier de la base de donnees : " <<endl;
              getline(cin,filename);
              m->Load(filename); //conversion en chaine de caracter
              break;
            }
            else if(fonction == 3)
            {
              string filename;
              cout<< "Indiquez le nom du fichier ou on sauvegarde" <<endl;
              getline(cin,filename);
              m-> Save(filename);
              break;
            }
            else if(fonction==4)
            {
              m->List();
              break;
            }
            else if(fonction == 5)
            {
              int id;
              cout<<"Indiquez l'id de la ressource a supprimer : "<<endl;
              cin >> id;
              cin.ignore(); // to clean
              m->Delete(id);
              break;
            }
            else if(fonction == 6)
            {
              int id;
              cout<<"Indiquez l'id de la ressource a afficher : "<<endl;
              cin >> id;
              cin.ignore();
              m->Show_id(id);
              break;
            }
            else if(fonction ==7)
            {
               string mot ;
               cout<< "c'est quoi le mot que vous cherchez? " <<endl;
               getline(cin,mot);
               m->Search(mot);
               break;
            }
            else if( fonction == 8)
            {
              m->Clear();
              break;
            }
            else if(fonction==9)
            {
              m->Reset();
              break;
            }
            else if(fonction==10)
            {
              m->Bye();
              break;
            }
            else if(fonction==11)
            {
              menu = true;
              acces1 = 0;
              acces2=1;
            }

            else
            {
              cout<<"Votre choix est invalide"<<endl;
            }



        }

      }
      else if( acces2==1)
      {
        cout<<endl;
        cout<<endl;
        cout<<"vous etes connecte dans la mediatheque en tant que client"<<endl;
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        cout<<"En tant que client , vous avez l'acces aux fonctions suivantes:"<<endl;
        cout<<endl;
        cout<<"1-List:Lister toutes les ressources disponibles"<<endl;
        cout<<"2-Show:Afficher les details d'une ressource donnee"<<endl;
        cout<<"3-Search:Rechercher une ressource"<<endl;
        cout<<"4-Reset:Reinitialiser la mediatheque"<<endl;
        cout<<"5-Use:emprunter ou rendre une ressource"<<endl;
        cout<<"6-Bye:quiter l'espace"<<endl;
        cout<<"7-changer le mode de connexion"<<endl;
        cout << endl;

        bool menu=false;
        while(!menu)
        {
            int fonction;
            cout<<"Taper le numero de l'action que vous souhaitez effectuer "<<endl;
            cin>>fonction;
            cin.ignore();//pour vider le tompon pour l'entree suivante


            if(fonction ==1)
            {
              m->List();
              break;
            }

           else if(fonction == 2 )
           {
             int id;
             cout<<"Indiquez l'id de la ressource a afficher : "<<endl;
             cin >> id;
             cin.ignore();
             m->Show_id(id);
             break;
           }

            else if(fonction == 3)
            {
               string mot ;
               cout<< "c'est quoi le mot que vous cherchez? " <<endl;
               getline(cin,mot);
               m->Search(mot);
               break;
            }

            else if(fonction==4)
            {
              m->Reset();
              break;
            }

            else if(fonction == 5)
            {
              int id;
              int use;
              cout<<"tapez l'identifiant de la ressource"<<endl;
              cin>>id;
              cout<<"Si vous voulez emprunter tapez 1, si vous rendez tapez 2"<<endl;
              cin>>use;
              if(use==1)
                  {
                    m->Use(id,"emprunter");
                  }
              else if( use==2)
                  {
                    m->Use(id,"retourner");
                  }
            }

            else if(fonction == 6)
            {
              m->Bye();
              break;
            }

            else if(fonction ==7)
            {
              menu = true;
              acces1 = 1;
              acces2=0;
            }

            else
            {
              cout<<"Votre choix est invalide"<<endl;
            }


      }
    }

  }
}
