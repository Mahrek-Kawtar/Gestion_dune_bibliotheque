#ifndef DEF_REVU
#define DEF_REVU
#include "Ressources.hpp"

#include "Livre.hpp"
#include <iostream>
#include <string>
#include <vector>


class Revue : public Livre {
//Methodes
    public:

    Revue();
    Revue( std::string _editeur,int _nbr_article,int _nbr_pages, std::string _auteur ,   int _date_de_pub , std::string _collection , std::string  _resume );
    ~Revue();


    virtual void ajouter();
    virtual void afficher();

    //La saisi des caractéristiques

    int ret_nbr_article();
    std::string ret_editeur();

    void save_revue(std::string filename);


    void set_nbr_article(int nv_nbr_article);
  void set_editeur(std::string nv_editeur);
  void set_titre(std::string nv_titre);
  void set_id(int nv_id);
  void set_type(std::string nv_type);

    //affectation des caractéristiques (pour modifier les valeurs...)

    void affectation( int _nbr_article ,  std::string saisir_editeur);

//Attributs
private:
    std::string editeur;
    int nbr_article;

};
#endif
