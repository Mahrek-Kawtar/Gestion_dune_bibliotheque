#include <iostream>
#include <fstream>
#include <vector>
#include "Livre.hpp"
#include "CD.hpp"
#include "VHS.hpp"
#include "Res_numerique.hpp"
#include <string>
#include <cstring>

using namespace std;

vector<Ressources*> medias; //pointeurs vers les objets(livre,CD,...)

void ajout_ressource(string type_ress){

    if( type_ress == "Livre" )
    {
        string date ="";
        string auteur="";
        string titre="";
        string resume="";
        string collec="";

        cout << "Saisir le titre: ";
        getline(cin, titre);
        cout << "Saisir l'auteur: ";
        getline(cin, auteur);
        cout << "Saisir la date: ";
        getline(cin, date);
        cout << "Saisir le resume: ";
        getline(cin, resume);
        cout << "Saisir la collection: ";
        getline(cin, collec);

        Livre* livre = new Livre(titre, auteur, stoi(date), collec, resume); // Création d'un objet Livre avec new

        medias.push_back(livre); // Ajout du pointeur vers l'objet Livre dans medias

    } else if( type_ress == "CD" ) {
        string nbr_piste="", duree="";
        string auteur="", produc="";

        cout << "Saisir le titre: ";
        getline(cin, titre);
        cout << "Saisir l'auteur: ";
        getline(cin, auteur);
        cout << "Saisir la duree: ";
        getline(cin, duree);
        cout << "Saisir le producteur: ";
        getline(cin, produc);
        cout << "Saisir le nombre de pistes: ";
        getline(cin, nbr_piste);

        CD* cd = new CD(titre, auteur, stoi(duree), produc, stoi(nbr_piste)); // Création d'un objet CD avec new

        medias.push_back(cd); 

    } else if( type_ress == "VHS" ) {
        string duree="", auteur="", produc="";

        cout << "Saisir la duree: ";
        getline(cin, duree);
        cout << "Saisir l'auteur: ";
        getline(cin, auteur);
        cout << "Saisir le producteur: ";
        getline(cin, produc);

        VHS* vhs = new VHS(stoi(duree), auteur, produc); 

        medias.push_back(vhs); 

    } else if( type_ress == "Ressource numerique" ) {
        string titre="", editeur="", chemin_acces="", type="";

        cout << "Saisir le titre: ";
        getline(cin, titre);
        cout << "Saisir l'editeur: ";
        getline(cin, editeur);
        cout << "Saisir le chemin d'acces: ";
        getline(cin, chemin_acces);
        cout << "Saisir le type: ";
        getline(cin, type);

        Res_numerique *res_numeriques=new Res_numerique(titre, editeur, chemin_acces, type);
         medias.push_back(res_numeriques);
          }
    else if(type_ress == "Revu")
    {
        string nbr_articles;
        string editeur, nom_article;

        cout << "Saisir l'editeur: ";
        getline(cin, editeur);
        cout << "Saisir le nombre d'articles: ";
        getline(cin, nbr_articles);
        cout << "Saisir le nom de l'article: ";
        getline(cin, nom_article);

        Revu *revu=new Revu(editeur, stoi(nbr_articles), nom_article);
        medias.push_back(revu);
    }  
     else if(type_ress == "DVD")
    {
        string nbr_piste, duree;
        string auteur, produc;
        cout << "Saisir l'auteur: ";
        getline(cin, auteur);
        cout << "Saisir la duree: ";
        getline(cin, duree);
        cout << "Saisir le producteur: ";
        getline(cin, produc);
        cout << "Saisir le nombre de pistes: ";
        getline(cin, nbr_piste);

        DVD *dvd=new DVD(stoi(duree), auteur, produc, stoi(nbr_piste));
         medias.push_back(dvd);
    }
  
    else {
        cout << "Type de ressource inconnu." << endl;
    }
}
void liberation_mem(){
   for( Ressource *res: medias){
      delete res;
   }
   medias.clear();
   }

/*void search_chaine(string chaine) {
  
}
void load_filename(string &filename,vector<Ressources*>res){
   res.clear();  //effacer les données existant pour les remplacer par des nouveaux
   string ch;
   ifstream infile;
   infile.open("filename.txt");
   while(!infile.eof) {
      getline(infile,ch);
      res.push_back(ch);
   }
   infile.close();

}

void Ressource::ajout_identifiant( const std::vector<int>& tableau , int idenfiant)
{
    int i =0 ;//pour parcourrir le tableau et vérifier que l'identifiant n'existe 
    while(i<tableau.size() && tableau[i] != identifiant)
    {
        i++;
    }
    if(i == tableau.size())
    {
    tableau.push_back(identifiant);
    }
    
}*/

void load_filename(const string &filename){
   vector<string> tab_res;
   tab_res.clear();  // Effacer les données existantes pour les remplacer par de nouvelles
 
   ifstream infile(filename.c_str());
   if(infile.is_open())
   {
      string ch;
      while (getline(infile, ch)){
         tab_res.push_back(ch);
         cout << ch << endl;
      }
      infile.close();
   }
   else{
      cout << "Échec de l'ouverture du fichier : " << filename << endl;
   }
}


int main(int argc, char **argv){

   if (argc>1) {
      if (strcmp(argv[1],"ADD")==0)
      {
      cout<<"saisi le type de ressource"<<endl;
      string type_ress;
      getline(cin,type_ress);
      ajout_ressource(type_ress);
      liberation_mem();
      } }
      //else if(strcmp(argv[1],"BYE")) {
      //...
    
     // liberation_mem();
   return 0;
}

/*main de load

int main(){
    string fichier = "fichier.txt";
    load_filename(fichier);
    return 0;
}
*/