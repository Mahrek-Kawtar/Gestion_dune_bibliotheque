#include "Mediatheque.hpp"
#include "Ressources.hpp"
#include "Res_numerique.hpp"
#include "Livre.hpp"
#include "CD.hpp"
#include "DVD.hpp"
#include "Revue.hpp"
#include "VHS.hpp"
#include <typeinfo>
#include <fstream>
#include <vector>

using namespace std;

Mediatheque:: Mediatheque(){

}

Mediatheque::~Mediatheque() {

}

void Mediatheque::Add(string _type)
{

  Ressources *ress;
  if (_type ==  "Livre" )
  {
          ress = new Livre();
          Livre *livre = dynamic_cast<Livre*>(ress);
          livre->ajouter();
  }

  if(_type =="Revue" )
  {
          ress = new Revue();
          Revue *revue = dynamic_cast<Revue*>(ress);
          revue ->ajouter();
  }

  else if(_type == "CD")
  {
          ress = new CD();
          CD *cd = dynamic_cast<CD*>(ress);
          cd -> ajouter ();
  }


  else if(_type == "VHS")
  {
          ress = new VHS();
          VHS *vhs = dynamic_cast<VHS*>(ress);
          vhs ->ajouter ();
  }


   else  if(_type == "DVD")
  {
          ress = new DVD();
          DVD *dvd = dynamic_cast<DVD*>(ress);
           dvd->ajouter ();
  }


 else if(_type == "Res_numerique")
  {
        ress = new Res_numerique();
        Res_numerique *res_num = dynamic_cast<Res_numerique*>(ress);
        res_num->ajouter ();
  }

   liste_des_ressources.push_back(ress);
   liste_pour_recherche.push_back(ress);
}




/*
void Mediatheque::Load(string filename){  //je charge un fichier en mettant son contenu dans un vecteur que je cree
   // Effacer les données existantes pour les remplacer par de nouvelles
   liste_des_ressources.clear();
   ifstream infile(filename.c_str());  //pour la lecture du fichier
   if(infile.is_open())
   {
      string line;
      while (getline(infile, line)){
         int taille=line.size();
        // int pos=line.find(";");

         if (line=="Livre"){   //c est un livre a charger
            Livre *nv_livre=new Livre();
              //  nv_livre->set_type("Livre");
              nv_livre->set_type(line);

                getline(infile,line);
                nv_livre->set_titre(line);
                getline(infile,line);
                nv_livre->set_etat(line);
                getline(infile,line);
                nv_livre->set_id(stoi(line));

                getline(infile,line);
                nv_livre->set_auteur(line);
                getline(infile,line);
                nv_livre->set_resume(line);
                getline(infile,line);
                nv_livre->set_collection((line));
                getline(infile,line);
                nv_livre->set_date_de_pub(stoi(line));
                getline(infile,line);
                nv_livre->set_nbr_pages(stoi(line));
                liste_des_ressources.push_back(nv_livre);

            }



*/

void Mediatheque::Load(string filename){  //je charge un fichier en mettant son contenu dans un vecteur que je cree
   // Effacer les données existantes pour les remplacer par de nouvelles
   liste_des_ressources.clear();
   ifstream infile(filename.c_str());  //pour la lecture du fichier
   if(infile.is_open())
   {
      string line;
      while (getline(infile, line)){
         int taille=line.size();
        // int pos=line.find(";");

         if (line=="Livre"){   //c est un livre a charger
            Livre *nv_livre=new Livre();
                nv_livre->set_type(line);
                getline(infile,line);
                nv_livre->set_titre(line);
                getline(infile,line);
                nv_livre->set_etat(line);
                getline(infile,line);
                nv_livre->set_id(stoi(line));
                getline(infile,line);
                nv_livre->set_auteur(line);
                getline(infile,line);
                nv_livre->set_resume(line);
                getline(infile,line);
                nv_livre->set_collection((line));
                getline(infile,line);
                nv_livre->set_date_de_pub(stoi(line));
                getline(infile,line);
                nv_livre->set_nbr_pages(stoi(line));

                liste_des_ressources.push_back(nv_livre);

            }

         else if (line=="CD") {
             CD *nv_cd=new CD();
                nv_cd->set_type(line);
                getline(infile,line);
                nv_cd->set_titre(line);
                getline(infile,line);
                nv_cd->set_etat(line);
                getline(infile,line);
                nv_cd->set_id(stoi(line));


                getline(infile,line);
                nv_cd->set_maison_prod(line);
                getline(infile,line);
                nv_cd->set_auteur(line);
                getline(infile,line);
                nv_cd->set_duree(stoi(line));
                getline(infile,line);
                nv_cd->set_nbr_piste(stoi(line));

                liste_des_ressources.push_back(nv_cd);
         }




       else if (line=="DVD") {
                DVD *nv_dvd=new DVD();
          nv_dvd->set_type(line);
            getline(infile,line);
            nv_dvd->set_type(line);
            getline(infile,line);
            nv_dvd->set_titre(line);
            getline(infile,line);
            nv_dvd->set_etat(line);
            getline(infile,line);
            nv_dvd->set_id(stoi(line));
            getline(infile,line);

            nv_dvd->set_maison_prod(line);
            getline(infile,line);
            nv_dvd->set_auteur(line);
            getline(infile,line);
            nv_dvd->set_duree(stoi(line));
            getline(infile,line);
            nv_dvd->set_nbr_piste(stoi(line));
            liste_des_ressources.push_back(nv_dvd);


         }


         else if (line=="VHS"){
              VHS *nv_vhs=new VHS();
            nv_vhs->set_type(line);
            getline(infile,line);
            nv_vhs->set_titre(line);
            getline(infile,line);
            nv_vhs->set_etat(line);
            getline(infile,line);
            nv_vhs->set_id(stoi(line));

            getline(infile,line);
            nv_vhs->set_duree(stoi(line));
            getline(infile,line);
            nv_vhs->set_auteur(line);
            getline(infile,line);
            nv_vhs->set_maison_prod(line);


         }

         else if (line=="Res_numerique"){
              Res_numerique *nv_Res_numerique=new Res_numerique();
            nv_Res_numerique->set_type("Res_numerique");
            getline(infile,line);
            nv_Res_numerique->set_titre(line);
            getline(infile,line);
            nv_Res_numerique->set_etat(line);
            getline(infile,line);
            nv_Res_numerique->set_id(stoi(line));
            getline(infile,line);

            nv_Res_numerique->set_auteur(line);
            getline(infile,line);
            nv_Res_numerique->set_type_num(line);
            getline(infile,line);
            nv_Res_numerique->set_taille(stoi(line));
            getline(infile,line);
            nv_Res_numerique->set_nom(line);
            getline(infile,line);
            nv_Res_numerique->set_chemin(line);

            liste_des_ressources.push_back(nv_Res_numerique);


         }
         else if (line=="Revue"){
            Revue *nv_revue=new Revue();
            nv_revue->set_type("Revue");
            getline(infile,line);
            nv_revue->set_titre(line);
            getline(infile,line);
            nv_revue->set_etat(line);
            getline(infile,line);
            nv_revue->set_id(stoi(line));

            getline(infile,line);
            nv_revue->set_auteur(line);
            getline(infile,line);
            nv_revue->set_resume(line);
            getline(infile,line);
            nv_revue->set_collection(line);
            getline(infile,line);
            nv_revue->set_date_de_pub(stoi(line));
            getline(infile,line);
            nv_revue->set_nbr_pages(stoi(line));
            getline(infile,line);
            nv_revue->set_nbr_article(stoi(line));
            getline(infile,line);
            nv_revue->set_editeur(line);
            liste_des_ressources.push_back(nv_revue);




         }
      }
      infile.close();
   }
   else{
          cout << "Échec de l'ouverture du fichier : " << filename << endl;
   }
}

/*
void Mediatheque::Load(string filename){  //je charge un fichier en mettant son contenu dans un vecteur que je cree
   // Effacer les données existantes pour les remplacer par de nouvelles
   liste_des_ressources.clear();
   ifstream infile(filename.c_str());  //pour la lecture du fichier
   if(infile.is_open())
   {
      string line;
      while (getline(infile, line)){
         int taille=line.size();
        // int pos=line.find(";");

         if (line=="Livre"){   //c est un livre a charger
            Livre *nv_livre=new Livre();
                nv_livre->set_type(line);
                getline(infile,line);
                nv_livre->set_titre(line);
                getline(infile,line);
                nv_livre->set_etat(line);
                getline(infile,line);
                nv_livre->set_id(stoi(line));
                getline(infile,line);
                nv_livre->set_auteur(line);
                getline(infile,line);
                nv_livre->set_resume(line);
                getline(infile,line);
                nv_livre->set_collection((line));
                getline(infile,line);
                nv_livre->set_date_de_pub(stoi(line));
                getline(infile,line);
                nv_livre->set_nbr_pages(stoi(line));
                liste_des_ressources.push_back(nv_livre);

            }

         else if (line=="CD") {
             CD *nv_cd=new CD();
                nv_cd->set_type(line);
                getline(infile,line);
                nv_cd->set_duree(stoi(line));
                getline(infile,line);
                nv_cd->set_maison_prod(line);
                getline(infile,line);
                nv_cd->set_auteur(line);
                getline(infile,line);
                nv_cd->set_id(stoi(line));
                liste_des_ressources.push_back(nv_cd);


}        else if (line=="DVD") {
                DVD *nv_dvd=new DVD();
            nv_dvd->set_type(line);
            getline(infile,line);
            nv_dvd->set_type(line);
            getline(infile,line);
            nv_dvd->set_titre(line);
            getline(infile,line);
            nv_dvd->set_etat(line);
            getline(infile,line);
            nv_dvd->set_id(stoi(line));
            getline(infile,line);
            nv_dvd->set_auteur(line);
            getline(infile,line);
            nv_dvd->set_maison_prod(line);
            getline(infile,line);
            nv_dvd->set_duree(stoi(line));
            getline(infile,line);
            nv_dvd->set_nbr_piste(stoi(line));
            liste_des_ressources.push_back(nv_dvd);
         }


         else if (line=="VHS"){
              VHS *nv_vhs=new VHS();
            nv_vhs->set_type(line);
            getline(infile,line);
            nv_vhs->set_type(line);
            getline(infile,line);
            nv_vhs->set_titre(line);
            getline(infile,line);
            nv_vhs->set_etat(line);
            getline(infile,line);
            nv_vhs->set_id(stoi(line));
            getline(infile,line);
            nv_vhs->set_auteur(line);
            getline(infile,line);
            nv_vhs->set_maison_prod(line);
            liste_des_ressources.push_back(nv_vhs);
         }

         else if (line=="Res_numerique"){
              Res_numerique *nv_Res_numerique=new Res_numerique();
            nv_Res_numerique->set_type(line);
            getline(infile,line);
            nv_Res_numerique->set_type(line);
            getline(infile,line);
            nv_Res_numerique->set_titre(line);
            getline(infile,line);
            nv_Res_numerique->set_etat(line);
            getline(infile,line);
            nv_Res_numerique->set_id(stoi(line));
            getline(infile,line);
            nv_Res_numerique->set_auteur(line);
            getline(infile,line);
            nv_Res_numerique->set_taille(stoi(line));
            getline(infile,line);
            nv_Res_numerique->set_nom(line);
            getline(infile,line);
            nv_Res_numerique->set_chemin(line);
            liste_des_ressources.push_back(nv_Res_numerique);
         }
         else if (line=="Revue"){
            Revue *nv_revue=new Revue();
            nv_revue->set_type(line);
            getline(infile,line);
            nv_revue->set_type(line);
            getline(infile,line);
            nv_revue->set_titre(line);
            getline(infile,line);
            nv_revue->set_etat(line);
            getline(infile,line);
            nv_revue->set_id(stoi(line));
            getline(infile,line);
            nv_revue->set_resume(line);
            getline(infile,line);
            nv_revue->set_collection(line);
            getline(infile,line);
            nv_revue->set_date_de_pub(stoi(line));
            getline(infile,line);
            nv_revue->set_nbr_pages(stoi(line));
            getline(infile,line);
            nv_revue->set_nbr_article(stoi(line));
            getline(infile,line);
            nv_revue->set_editeur(line);
            liste_des_ressources.push_back(nv_revue);
         }
      }
      infile.close();
   }
   else{
          cout << "Échec de l'ouverture du fichier : " << filename << endl;
   }
}
*/

/*
void Mediatheque::Save( string filename){


   ofstream outfile(filename);

  if(outfile.is_open())
  {
   for(auto& ressource:liste_des_ressources){
      if(ressource->retourner_type()=="Livre"){
         Livre *livre=dynamic_cast<Livre*>(ressource);
         livre->save_livre(filename);
      }
      else if(ressource->retourner_type()=="CD"){
         CD *cd=dynamic_cast<CD*>(ressource);
         cd->save_cd(filename);
      }
      else if(ressource->retourner_type()=="DVD"){
         DVD *dvd=dynamic_cast<DVD*>(ressource);
         dvd->save_dvd(filename);
      }
      else if(ressource->retourner_type()=="Revue"){
         Revue *revue=dynamic_cast<Revue*>(ressource);
         revue->save_revue(filename);
      }
      else if(ressource->retourner_type()=="VHS"){
         VHS *vhs=dynamic_cast<VHS*>(ressource);
         vhs->save_vhs(filename);
      }
      else if(ressource->retourner_type()=="Res_numerique"){
         Res_numerique *res_num=dynamic_cast<Res_numerique*>(ressource);
         res_num->save_re_num(filename);

      }
   }
   outfile.close();
  }
      else {
         cout<<"Echec d ouverture du fichier"<<filename<<endl;
    }

}*/





void Mediatheque::Save( string filename){

  ofstream outfile;

  Ressources *ma_res;

  outfile.open(filename);
  if(outfile.is_open())
  {
    int i;//pour parcourrir le tableux des differentes ressources
    for (i=0; i<liste_des_ressources.size() ; i++)
     {
         ma_res = liste_des_ressources.at(i);
         string type = ma_res->retourner_type();
         outfile << type<<endl;
         string titre = ma_res->retourner_titre();
         outfile << titre<<endl;
         int id = ma_res->retourner_id();
         outfile << to_string(id)<<endl;
         string etat = ma_res->retourner_etat();
         outfile << etat<<endl;

       if( type =="Livre" )
       {
            Livre *mon_livre= new Livre();//construction
            mon_livre = dynamic_cast<Livre*>(ma_res);
            mon_livre->save_livre(filename);
       }
       else if(type=="Revue")
        {
            Revue *ma_revue= new Revue();
            ma_revue = dynamic_cast<Revue*>(ma_res);
            ma_revue->save_revue(filename);
        }
        else if(type=="CD")
        {
            CD *mon_cd = new CD();
            mon_cd = dynamic_cast<CD*>(ma_res);
            mon_cd->save_cd(filename);
        }
        else if( type == "VHS")
        {
          VHS *mon_vhs = new VHS();
          mon_vhs =  dynamic_cast<VHS*>(ma_res);
          mon_vhs -> save_vhs(filename);
        }
        else if (type== "DVD")
        {
          DVD *mon_dvd = new DVD();
          mon_dvd =  dynamic_cast<DVD*>(ma_res);
          mon_dvd -> save_dvd(filename);
        }
        else if( type=="Res_numerique")
        {
          Res_numerique *ma_res_num = new Res_numerique();
          ma_res_num =  dynamic_cast<Res_numerique*>(ma_res);
          ma_res_num -> save_re_num(filename);
        }
   }
outfile.close();

  }
  else {
    cout<<"Echec d ouverture du fichier"<<filename<<endl;
    }
}


void Mediatheque::Search (string mot )
{
   Ressources *r;
   int i;
   for(i=0; i<liste_pour_recherche.size(); i++)
   {
       r=liste_pour_recherche.at(i);
       if(r->retourner_titre()==mot)
       {
         resultats_recherche.push_back(liste_pour_recherche.at(i));
         cout<<"on a trouve une ressource avec ce titre"<<endl;
       }
       else {
              if( r->retourner_type()=="Livre")//On va chercher dans les attributs
              {
                    Livre *l = new Livre();
                    l=dynamic_cast<Livre*>(r);

                    if(l->ret_auteur() == mot)
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
                    else if(l->ret_resume() == mot )
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
                    else if(l->ret_collection() == mot )
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
              }
              else if( r->retourner_type()=="Revue" )
              {
                    Revue *re = new Revue();
                    re= dynamic_cast<Revue*>(r);

                    if(re->ret_auteur() == mot)
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
                    else if(re->ret_resume() == mot )
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
                    else if(re->ret_collection() == mot )
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }

                    else if( re-> ret_editeur() == mot)
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
              }
              else if(r->retourner_type()=="CD")
              {
                    CD *cd = new CD();
                    cd = dynamic_cast<CD*>(r);

                    if(cd->ret_auteur()==mot)
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
                    else if(cd->ret_maison_prod()==mot)
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
              }
              else if ( r->retourner_type()=="VHS")
              {
                    VHS *vhs=new VHS();
                    vhs = dynamic_cast<VHS*>(r);

                    if ( vhs->ret_auteur() == mot)
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
                    else if( vhs-> ret_maison_prod() ==mot)
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }

              }
              else if ( r->retourner_type() == "DVD")
              {
                    DVD *dvd = new DVD();
                    dvd = dynamic_cast<DVD*>(r);
                    if ( dvd->ret_auteur() == mot)
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
                    else if ( dvd-> ret_maison_prod() ==mot)
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
              }
              else if( r-> retourner_type() =="Res_numerique")
              {
                    Res_numerique *r_num = new Res_numerique();
                    r_num = dynamic_cast<Res_numerique*>(r);
                    if(r_num ->ret_auteur()==mot)
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
                    else if (r_num ->ret_nom()==mot)
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
                    else if(r_num ->ret_chemin()==mot)
                    {
                      resultats_recherche.push_back(liste_pour_recherche.at(i));
                    }
              }


              int n= resultats_recherche.size();
              if(n==0)
              {
                cout<< "Aucune ressource ne correspond a votre recherche \n"<< endl;
              }
              else
              {
                  for(i=0; i<n ; i++)
                  {
                      r=resultats_recherche.at(i);
                      cout<<"----------------Les resultats de la recherche:----------------"<<endl;
                      cout<<"La ressource trouvee numero "<<i+1 <<" est:"<<endl;
                      r->afficher();
                  }
              }
       }
     liste_pour_recherche = resultats_recherche;
      liste_des_ressources.clear();//pour que la recherche prochaine se basera sur les resultats de la precedente
   }}


 /* void Mediatheque:: Delete(int identifiant)
  {
      for(auto& ressource:liste_des_ressources )
      {
       if(ressource->retourner_id()==identifiant)
       {
           delete ressource;
           //liste_des_ressources.erase(ressource);
       }
    }
 }*/
void Mediatheque::Delete(int identifiant) {
    for (auto ress = liste_des_ressources.begin(); ress != liste_des_ressources.end(); ress++) {
        if ((*ress)->retourner_id() == identifiant) {
            delete *ress;   //libère la mémoire allouée dynamiquement
            liste_des_ressources.erase(ress);  // enlève la ressource du vecteur
            return;
        }
  }
    cout << "Ressource avec l'ID " << identifiant << " non trouvée." << endl;
}
 void Mediatheque::Reset()
 {
   for(auto& ressource:liste_des_ressources ){
     delete(ressource);
     liste_des_ressources.clear();
   }
 }

   void Mediatheque ::List()
   {
       Ressources *r;
       int i=0;
       int n= liste_des_ressources.size();
       if(n==0)
       {
         cout<< "il n'y a rien a afficher \n"<< endl;
       }
       else
       {
           for(i=0; i<n ; i++)
           {
               r=liste_des_ressources.at(i);
               cout<<"-La liste des ressource de notre mediatheque est la suivante:"<<endl;

               cout<<"--------------------------------"<<endl;
               cout<<"La ressource numero  "<<i<<"  a les attributs suivants :"<<endl;
               r->afficher();
           }
       }
   }


   void Mediatheque:: Clear()
   {
     liste_pour_recherche = liste_des_ressources;
     resultats_recherche.clear();

   }

   void Mediatheque:: Use(int id , string action )
   {
     Ressources *r;
     int i=0;
     int k=0;
     for(i=0;i<liste_des_ressources.size();i++)
     {
          r = liste_des_ressources.at(i);
          if(r->retourner_id() == id)
          {
              k=1;
              if(action =="emprunter" && r->retourner_etat() =="disponible" )
              {
                  cout<<"la ressource est disponible"<<endl;
                  cout<<"vous allez emprunter une ressource pour une semaine"<<endl;
                  r->affectation_etat("indisponible");
              }
              else if(action =="emprunter" && r->retourner_etat() =="indisponible")
              {
                  cout<<"la ressource n'est pas disponible"<<endl;
              }


              else if(action == "retourner" )
              {
                  r->affectation_etat("disponible");
                  cout<<"Vous avez rendu une ressource"<<endl;
              }
          }
     }
     if(k==0)
     {
       cout<<"l'identifiant n'existe pas"<<endl;
     }
   }



   void Mediatheque:: Show_id(int _identifiant){
      bool ressource_found=false;
      Ressources *ressource;
      for(auto& ressource:liste_des_ressources ){
       if (ressource->retourner_id()==_identifiant && ressource->retourner_type()=="Livre"){
          Livre *livre=dynamic_cast<Livre*>(ressource);
      //transformer la ressource de type livre a un objet livre
      cout<<"Les informations relative a la ressource sont:"<<endl;
          livre->afficher();
          ressource_found=true;
       }
       if (ressource->retourner_id()==_identifiant && ressource->retourner_type()=="CD"){
          CD *cd=dynamic_cast<CD*>(ressource);
          cout<<"Les informations relative a la ressource sont:"<<endl;
          cd->afficher();
          ressource_found=true;
       }
       if (ressource->retourner_id()==_identifiant && ressource->retourner_type()=="DVD"){
          DVD *dvd=dynamic_cast<DVD*>(ressource);
            cout<<"Les informations relative a la ressource sont:"<<endl;
          dvd->afficher();
          ressource_found=true;
       }
       if (ressource->retourner_id()==_identifiant && ressource->retourner_type()=="Revu"){
          Revue *revue=dynamic_cast<Revue*>(ressource);
            cout<<"Les informations relative a la ressource sont:"<<endl;
          revue->afficher();
          ressource_found=true;
       }
       if (ressource->retourner_id()==_identifiant && ressource->retourner_type()=="VHS"){
          VHS *vhs=dynamic_cast<VHS*>(ressource);
            cout<<"Les informations relative a la ressource sont:"<<endl;
          vhs->afficher();
          ressource_found=true;
       }
       if (ressource->retourner_id()==_identifiant && ressource->retourner_type()=="Res_numerique"){
          Res_numerique *res_numerique=dynamic_cast<Res_numerique*>(ressource);
            cout<<"Les informations relative a la ressource sont:"<<endl;
          res_numerique->afficher();
          ressource_found=true;
       }
      }
      if(!ressource_found){
         cout<<"Il n ya pas de ressource avec cet identifiant"<<endl;
      }}

void Mediatheque::Bye(){
   cout<<"Vous Allez quitter votre espqce sur la mediatheque"<<endl;
   exit(0);
   }
