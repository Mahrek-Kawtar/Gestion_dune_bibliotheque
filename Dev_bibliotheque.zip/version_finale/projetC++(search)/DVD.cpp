#include "DVD.hpp"
#include "VHS.hpp"
using namespace std;

DVD::DVD() {

}
DVD::DVD(int _duree,string _auteur, string _maison_prod,int _nbr_piste){


}

void ajout_DVD(int nbr_piste){

}

DVD::~DVD () {

}

void DVD::ajouter()
{
  string s ;

  cout << "Reinserer le type " <<endl;
  getline(cin,s);
  type = s;

  //
  cout << "Inserer le titre " <<endl;
  getline(cin,s);
  titre = s;


  cout << "Inserer l etat " <<endl;
  getline(cin,s);
  etat = s;

  cout << "Inserer l'identifiant" <<endl;
  getline(cin,s);
  id = atoi(s.c_str());

  cout << "Inserer le nom de l'auteur " <<endl;
  getline(cin,s);
  auteur = s;

  cout << "inserer le nom de la maison de production du DVD? :" <<endl;
  getline(cin,s);
  maison_prod = s;

  cout << "Ce DVD dure combien?" <<endl;
  getline(cin,s);
  duree = atoi(s.c_str());

  cout << "y a combien de pistes? :" <<endl;
  getline(cin,s);
  nbr_piste = atoi(s.c_str());

}

void DVD::afficher()
{
 VHS::afficher();
  cout<<"le nombre de pistes est "<<nbr_piste<<endl;
}


int DVD:: ret_nbr_piste()
{
  return nbr_piste;
}
///fct setAttributs
 void DVD::set_type(string nv_type)
    {
     type=nv_type;
    }
  void DVD::set_duree(int nv_duree)
    {
     duree=nv_duree;
    }

  void DVD::set_auteur(string nv_auteur)
    {
      auteur=nv_auteur;
    }

  void DVD::set_titre(string nv_titre)
    {
       titre= nv_titre;
    }
  void DVD::set_etat(string nv_etat)
    {
       etat= nv_etat;
    }
  void DVD::set_id(int nv_id)
    {
       id=nv_id;
    }
  void DVD::set_nbr_piste(int nv_nbr_piste)
  {
       nbr_piste=nv_nbr_piste;
    }

  void DVD::set_maison_prod(string nv_maison_prod)
  {
       nv_maison_prod=nv_maison_prod;
    }



void DVD:: save_dvd (string filename)
{
  ofstream infile;
  infile.open(filename);
  VHS:: save_vhs(filename);
  infile<< to_string(nbr_piste)<<endl;

}
