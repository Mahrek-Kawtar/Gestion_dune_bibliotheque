#include "VHS.hpp"

using namespace std;


VHS::VHS() {
    auteur = "";
    duree=0;
    maison_prod="";

}
VHS::VHS(int _duree,string _auteur, string _maison_prod){
  duree = _duree;
  auteur = _auteur;
  maison_prod = _maison_prod;
}
VHS::~VHS() {

}

void VHS::ajouter()
{
  string s ;

        //ces trois premiers sont communs =>copie et colle
        cout << "Reinserer le type " <<endl;
        getline(cin,s);
        type = s;

          cout << "Inserer le titre " <<endl;
          getline(cin,s);
          titre = s;


          cout << "Inserer l etat " <<endl;
          getline(cin,s);
          etat = s;

          cout << "Inserer l'identifiant" <<endl;
          getline(cin,s);
          id = atoi(s.c_str());
          //

          cout << "Inserer le nom de l'auteur " <<endl;
          getline(cin,s);
          auteur = s;

          cout << "inserer le nom de la maison de production du VHS? :" <<endl;
          getline(cin,s);
          maison_prod = s;

          cout << "Ce VHS dure combien?" <<endl;
          getline(cin,s);
          duree = atoi(s.c_str());
}

void VHS::afficher()
{
    Ressources:: afficher();
    cout<<"l'auteur est:"<<auteur<<endl;
    cout<<"la maison de production est:"<<maison_prod<<endl;
    cout<<"le VHS dure:"<<duree<<endl;
}



string VHS::ret_auteur()
{
    return auteur;
}
int VHS::ret_duree()
{
    return duree;
}
string VHS::ret_maison_prod()
{
    return maison_prod;
}

void VHS::save_vhs(string filename)
{
  ofstream infile;
  infile.open(filename);

  infile << auteur <<endl;
  infile <<maison_prod <<endl;
  infile<<to_string(duree)<<endl;
}


void VHS:: set_auteur(string nv_auteur)
{
    auteur=nv_auteur;
}
void VHS::set_duree(int nv_duree)
{
     duree=nv_duree;
}
void VHS:: set_maison_prod(string nv_maison_prod)
{
     maison_prod=nv_maison_prod;
}
void VHS:: set_titre(string nv_titre){
     titre=nv_titre;
}
void VHS::set_id(int nv_id){
     id=nv_id;
}
void VHS:: set_type(string nv_type){
     type=nv_type;
}
void VHS:: set_etat(string nv_etat){
     etat=nv_etat;
}



void VHS:: affectation(int _duree,std::string _auteur ,std::string _maison_prod)
{
  duree =_duree;
  auteur =_auteur;
  maison_prod = _maison_prod;
}
