#include "Revue.hpp"

using namespace std;

//constructeur en utilisant le constructeur de livre et ajouter les attributs suplementaires
Revue::Revue(string  _editeur,int _nbr_article,int _nbr_pages,string _auteur , int _date_de_pub,string _collection ,string  _resume):  Livre( _nbr_pages, _auteur ,_date_de_pub , _collection , _resume  ),nbr_article(_nbr_article), editeur(_editeur)
{

}

Revue::Revue(){
  Livre();
  nbr_article = 0;
  editeur = "";
}
Revue::~Revue(){

}


void Revue ::ajouter()
    {
      Livre :: ajouter();

      string s ;
      cout << "la revue contient combien d'articles? :" <<endl;
      getline(cin,s);
      nbr_article = atoi(s.c_str());
      cout << "taper le nom de l'editeur :" <<endl;
      getline(cin,s);
      editeur = s;
    }

void Revue::afficher()
{
  Livre :: afficher();

  cout<<"la revue contient"<<nbr_article<<"d'articles"<<endl;
  cout<<editeur<<"est l'editeur"<<endl;

}

int Revue::ret_nbr_article() {
	return nbr_article;
}

string Revue::ret_editeur() {
	return editeur;
}



void Revue::set_nbr_article(int nv_nbr_article){
    nbr_article=nv_nbr_article;
}
void Revue:: set_editeur(string nv_editeur){
    editeur=nv_editeur;
}
void Revue:: set_titre(string nv_titre){
    titre=nv_titre;
}
void Revue:: set_id(int nv_id){
    id=nv_id;
}
void Revue:: set_type(string nv_type){
    type=nv_type;
}


void Revue::save_revue(string filename)
{
  ofstream infile;
  infile.open(filename);

  Livre:: save_livre(filename);

  infile<<to_string(nbr_article)<<endl;
  infile<<to_string(date_de_pub)<<endl;
}

void Revue:: affectation (int _nbr_article, string _editeur)
{
  nbr_article =_nbr_article;
  editeur=_editeur;
}
