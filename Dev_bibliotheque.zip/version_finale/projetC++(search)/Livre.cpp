#include "Livre.hpp"

//#include "Ressources.hpp"

using namespace std;

Livre::Livre()
    {
        nbr_pages=0;
        auteur ="";
        date_de_pub=0;
        collection="";
        resume ="";

    }

Livre::Livre( int _nbr_pages, string _auteur ,int _date_de_pub , string _collection , string  _resume  )
    {

    }

Livre::~Livre()
    {

    }

void Livre ::ajouter()
    {
      string s ;

      //ces trois premiers sont commun =>copie et colle
      cout << "Reinserer le type " <<endl;
      getline(cin,s);
      type = s;

        cout << "Inserer le titre " <<endl;
        getline(cin,s);
        titre = s;


        cout << "Inserer l etat " <<endl;
        getline(cin,s);
        etat = s;

        cout << "Inserer l'identifiant" <<endl;
        getline(cin,s);
        id = atoi(s.c_str());
        //

      cout << "Inserer le nom de l'auteur " <<endl;
      getline(cin,s);
      auteur = s;


      cout << "inserer le  resume du livre :" <<endl;
      getline(cin,s);
      resume = s;


      cout << "inserer le nom de la collection du livre ? :" <<endl;
      getline(cin,s);
      collection = s;

      cout << "Inserer l'annee de publication? :" <<endl;
      getline(cin,s);
      date_de_pub = atoi(s.c_str());

      cout << "y a combien de pages? :" <<endl;
      getline(cin,s);
      nbr_pages = atoi(s.c_str());
    }



    void Livre::afficher()
    {
      Ressources::afficher();
      cout <<" Auteur: "<<auteur<<endl;
      cout <<" Collection: "<<collection<<endl;
      cout <<" Resume: "<<resume<<endl;
      cout <<" Annee de publication: "<<date_de_pub <<endl;
      cout <<" Nombre de pages: "<<nbr_pages<<endl;
    }

    void Livre::affectation(int _nbr_pages, std::string _auteur ,  int _date_de_pub , std::string _collection , std::string  _resume )
    {
        nbr_pages =_nbr_pages;
        auteur = _auteur;
        date_de_pub = _date_de_pub;
        collection=_collection;
        resume =_resume;
    }

//le role de ces mth est de retourner les attribut //ces fonctions
    int Livre::ret_nbr_pages()
    {
      return nbr_pages;
    }

    string Livre::ret_auteur()
    {
      return auteur;
    }

    int Livre::ret_date_de_pub()
    {
      return date_de_pub ;
    }

    string Livre::ret_collection()
    {
      return collection ;
    }

    string Livre::ret_resume()
    {
      return resume ;
    }



    ///fct setAttributs
     void Livre::set_type(string nv_type)
        {
         type=nv_type;
        }

     void Livre::set_nbr_pages(int nv_nbr_pages)
        {
         nbr_pages=nv_nbr_pages;
        }

      void Livre::set_auteur(string nv_auteur)
        {
          auteur=nv_auteur;
        }

      void Livre::set_date_de_pub(int nv_date_de_pub)
        {
          date_de_pub=nv_date_de_pub ;
        }

      void Livre::set_collection(string nv_collection)
        {
          collection= nv_collection;
        }

      void Livre::set_resume(string nv_resume)
        {
           resume= nv_resume;
        }
      void Livre::set_titre(string nv_titre)
        {
           titre= nv_titre;
        }
      void Livre::set_id(int nv_id)
        {
           id=nv_id;
        }
        void Livre::set_etat(string nv_etat)
        {
           etat=nv_etat;
        }



    void Livre::save_livre(string filename)
    {
        ofstream infile;
        infile.open(filename);

       infile << type<<endl;
       infile << titre<<endl;
       infile << etat<<endl;
       infile << to_string(id)<<endl;
       infile << auteur<<endl;
       infile << resume<<endl;
      infile << collection<<endl; 
      infile<<to_string(date_de_pub)<<endl;
      infile<<to_string(nbr_pages)<<endl;
      
    }
