#include <iostream>
#include "Mediatheque.hpp"
#include "Ressources.hpp"


using namespace std;

int main()
{

    Mediatheque *m = new Mediatheque();
    m->utilisation(5,"emprunter");
    return 1;
  }
