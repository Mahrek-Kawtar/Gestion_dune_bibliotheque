#include "CD.hpp"

using namespace std;

CD::CD(){
  auteur = "";
  duree = 0;
  nbr_piste=0;
  maison_prod ="";

}

CD::CD(string _titre,int _duree,int _nbr_piste, string _auteur,string _maison_prod)
{

}


CD::~CD() {
}

void CD::ajouter()
{
//  Ressources :: ajouter();
  string s ;

//ces trois premiers sont commun =>copie et colle
cout << "Reinserer le type " <<endl;
getline(cin,s);
type = s;

  cout << "Inserer le titre " <<endl;
  getline(cin,s);
  titre = s;


  cout << "Inserer l etat " <<endl;
  getline(cin,s);
  etat = s;

  cout << "Inserer l'identifiant" <<endl;
  getline(cin,s);
  id = atoi(s.c_str());
  //

  cout << "Inserer le nom de l'auteur " <<endl;
  getline(cin,s);
  auteur = s;

  cout << "inserer le nom de la maison de production du CD ? :" <<endl;
  getline(cin,s);
  maison_prod = s;

  cout << "Ce CD dure combien?" <<endl;
  getline(cin,s);
  duree = atoi(s.c_str());

  cout << "y a combien de pistes? :" <<endl;
  getline(cin,s);
  nbr_piste = atoi(s.c_str());

}

void CD::afficher()
{
  Ressources::afficher();
  cout <<"l'auteur:"<<auteur<<endl;
  cout <<"la duree"<<auteur<<endl;
  cout <<"la maison de production:"<<auteur<<endl;
  cout <<"le nombre de pistes:"<<nbr_piste<<endl;
}



int CD::ret_duree()
{
  return duree;
}
string CD::ret_maison_prod()
{
  return maison_prod;
}
string CD::ret_auteur()
{
  return auteur;
}
int CD::ret_nbr_piste()
{
  return nbr_piste;
}

///fct setAttributs
 void CD::set_type(string nv_type)
    {
     type=nv_type;
    }

void CD::set_etat(string nv_etat)
        {
         etat=nv_etat;
        }
void CD::set_nbr_piste(int nv_nbr_piste)
{
   nbr_piste=nv_nbr_piste;
}
void CD::set_maison_prod(string nv_maison_prod)
{
   maison_prod=nv_maison_prod;
}
  void CD::set_auteur(string nv_auteur)
    {
      auteur=nv_auteur;
    }
  void CD::set_duree(int nv_duree)
    {
      duree=nv_duree;
    }

  void CD::set_titre(string nv_titre)
    {
       titre= nv_titre;
    }
  void CD::set_id(int nv_id)
    {
       id=nv_id;
    }


void CD::save_cd (string filename)
{
              ofstream infile;
               infile.open(filename);
               infile << type<<endl;
               infile << titre <<endl;
               infile << etat<<endl;
               infile << to_string(id) <<endl;
               infile <<maison_prod<<endl;
               infile << auteur<<endl;
               infile << to_string(duree) <<endl;
               infile << to_string(nbr_piste) <<endl;
               

}
