#include "Res_numerique.hpp"

using namespace std;

Res_numerique::Res_numerique() {

    nom ="";
    chemin_acces = "";
    auteur ="";
    taille = 0;
    type = "";
}
Res_numerique::Res_numerique( int _taille,std::string _auteur,std::string _type,std::string _nom,std::string _chemin_acces) {

}
Res_numerique::~Res_numerique() {

}


void Res_numerique:: ajouter(){

    string s;

    cout << "Reinserer le type " <<endl;
    getline(cin,s);
    type = s;

    cout << "Inserer le titre " <<endl;
    getline(cin,s);
    titre = s;


    cout << "Inserer l etat " <<endl;
    getline(cin,s);
    etat = s;

    cout << "Inserer l'identifiant" <<endl;
    getline(cin,s);
    id = atoi(s.c_str());

    cout << "Nom de l'auteur ?" <<endl;
    getline(cin,s);
    auteur = s;

    cout << "Indiquez la taille :" <<endl;
    getline(cin,s);
    taille = atoi(s.c_str());

    cout << "cette ressource numerique est de quel type ?" <<endl;
    getline(cin,s);
    type = s;

    cout << "inserer le nom du document  :" <<endl; //il coincide peut etre avec le titre
    getline(cin,s);
    nom = s;

    cout << "chemin_acces :" <<endl;
    getline(cin,s);
    chemin_acces = s;
}


void Res_numerique::afficher()
{
  Ressources::afficher();
  cout <<" l'auteur est: "<<auteur<<endl;
  cout <<" le nom: "<<nom<<endl;
  cout <<" la taille est: "<<taille<< "octets"<<endl;
  cout <<" le type est: "<<type<<endl;
  cout <<"le lien d'acces est: "<<chemin_acces<<endl;
}

string Res_numerique:: ret_auteur() {
	return auteur;
}
int Res_numerique:: ret_taille() {
	return taille;
}

string Res_numerique:: ret_nom() {
	return nom;
}
string Res_numerique:: ret_type() {
	return type;
}
string Res_numerique:: ret_chemin() {
	return chemin_acces;
}

void Res_numerique::affectation( int _taille ,string _auteur ,string _type,std::string _nom,string _chemin_acces)
{
  auteur=_auteur;
  taille =_taille;
  chemin_acces=_chemin_acces ;
  type =_type;
  nom =_nom;
}


    void Res_numerique:: set_taille(int nv_taille){
      taille=nv_taille;

    }

    void Res_numerique::set_type(string nv_type)
       {
        type=nv_type;
       }

    void Res_numerique:: set_auteur(string nv_auteur){
      auteur=nv_auteur;
    }
    void Res_numerique:: set_type_num(string nv_type){
      type=nv_type;
    }
    void Res_numerique:: set_nom(string nv_nom){
      nom=nv_nom;
    }
    void Res_numerique:: set_chemin(string nv_chemin_acces){
      chemin_acces=nv_chemin_acces;
    }
    void Res_numerique::set_titre(std::string nv_titre){
      titre=nv_titre;
    }
    void  Res_numerique::set_id(int nv_id){
      id=nv_id;
    }
    void Res_numerique::set_etat(std::string nv_etat){
      etat=nv_etat;
    }


void Res_numerique::save_re_num(string filename)
{
  ofstream infile;
  infile.open(filename);

  infile << auteur <<endl;
  infile << chemin_acces<<endl;
  infile << type <<endl;
  infile << nom <<endl;
  infile<<to_string(taille)<<endl;
}
