#ifndef DEF_VHS
#define DEF_VHS
#include "Ressources.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <fstream>


class VHS  :public Ressources {
  public:

  VHS() ;
  VHS(int _duree , std::string _auteur, std::string _maison_prod);
  ~VHS() ;


    //others

    virtual void ajouter();
    virtual void afficher();

    //La saisi des caractéristiques

    int  ret_duree();
    std::string ret_auteur();
    std::string ret_maison_prod ();




        void set_duree(int nv_duree);
        void set_auteur(std::string nv_auteur);
        void set_maison_prod (std::string nv_maison_prod);
        void set_titre(std::string nv_titre);
        void set_id(int nv_id);
        void set_type(std::string type);
        void set_etat(std::string etat);



    void save_vhs(std::string filename);

    //affectation des caractéristiques (pour modifier les valeurs...)

    void affectation(int _duree,std::string _auteur ,std::string _maison_prod);
   //Attributs
   protected:

  int duree ;
  std::string auteur;
  std::string maison_prod;



};
#endif
