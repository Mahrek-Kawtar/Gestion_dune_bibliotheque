#ifndef DEF_LIVRE
#define DEF_LIVRE

#include "Ressources.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>

class Livre : public Ressources {


//METHODES

    public:

    //constructeurs et destructeur
    Livre();
    Livre( int _nbr_pages, std::string _auteur ,  int _date_de_pub , std::string _collection , std::string  _resume  );
    ~Livre();

    //others

    virtual void ajouter();
    virtual void afficher();

    //La saisi des caractéristiques

    int ret_nbr_pages();
    std::string ret_auteur();
    int  ret_date_de_pub ();
    std::string ret_collection ();
    std::string  ret_resume ();

    //setAttributs
        void set_type(std::string nv_type);
       void set_nbr_pages(int nv_nbr_pages);
       void set_auteur(std::string nv_auteur);
       void set_date_de_pub (int nv_date_de_pub);
       void set_collection (std::string nv_collection);
       void set_resume (std::string nv_resume);
       void set_titre(std::string nv_titre);
       void set_id(int nv_id);
       void set_etat(std::string nv_etat);
       

    void save_livre(std::string filename);

    //affectation des caractéristiques (pour modifier les valeurs...)

    void affectation (int _nbr_pages,std::string _auteur, int _date_de_pub,std::string _collection,std::string _resume );


//ATTRIBUTS

    protected:

    int nbr_pages;
    std::string auteur;
    int date_de_pub ;
    std::string collection;
    std::string resume ;

};
#endif
