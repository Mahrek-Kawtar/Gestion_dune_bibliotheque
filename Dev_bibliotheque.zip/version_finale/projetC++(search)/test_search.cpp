#include <iostream>
#include "Mediatheque.hpp"
#include "Ressources.hpp"


using namespace std;

int main()
{

    Mediatheque *m = new Mediatheque();
    string mot = "roman";
    m-> Search(mot);
    return 1;
  }
