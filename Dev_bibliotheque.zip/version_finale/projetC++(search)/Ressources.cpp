#include "Ressources.hpp"

using namespace std;

Ressources::Ressources(){
            type ="";
            id =0;
            etat="";
            titre = "";
            }
Ressources::Ressources( string _type ,int _id,string _etat, string  _titre)
{

}

Ressources::~Ressources()
{

}

void Ressources::afficher(){
cout <<"l'idetifiant est : "<<id<<endl;
cout <<"le titre est : "<<titre <<endl;
cout <<"le type est : "<<type<<endl;
cout <<"l'etat est : "<< etat<<endl;
}

void Ressources::ajouter(){

}


int Ressources::retourner_id()
{
  return id;
}
string Ressources::retourner_type() {
	return type;
}

string Ressources::retourner_etat() {
	return etat;
}

string Ressources::retourner_titre()
{
  return titre;
}



void Ressources::affectation_etat(string _etat)
{
  etat=_etat;
}
/*
void Ressources::affectation (std::string _type,int _id, std::string _etat,std::string _titre)
{
  type=_type;
  id=_id;
  etat=_etat;
  titre=_titre;
}*/
//std::string titre,std::string auteur,std::string date_de_pub,std::string collection,std::string resume,int nbr_piste, std::string editeur,int nbr_article,string nom_article,string auteur, int duree,std::string maison_prod,std::string type,
  //  std::string chemin_acces){
